import xbmc
import xbmcgui
import xbmcaddon
import urllib.request
import json

class KEService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.window = None
        self.addon = xbmcaddon.Addon()

    def get_ke_data(self):
        ip = self.addon.getSetting('server_ip')
        port = self.addon.getSetting('server_port')
        try:
            url = f"http://{ip}:{port}/api/status" # Adapte l'URL de ton API
            with urllib.request.urlopen(url, timeout=2) as r:
                return json.loads(r.read().decode())
        except:
            return None

    def run(self):
        while not self.abortRequested():
            if not xbmc.Player().isPlaying():
                # On met à jour les propriétés pour le XML
                data = self.get_ke_data()
                if data:
                    win = xbmcgui.Window(10000)
                    win.setProperty('KE.NextSinger', data.get('nextSinger', 'Attente...'))
                    win.setProperty('KE.QueueCount', str(data.get('count', '0')))
                
                if self.window is None:
                    # On affiche l'écran d'attente
                    self.window = xbmcgui.WindowXML('waiting_screen.xml', self.addon.getAddonInfo('path'))
                    self.window.show()
            else:
                if self.window:
                    self.window.close()
                    self.window = None
            
            if self.waitForAbort(3): break

if __name__ == '__main__':
    KEService().run()